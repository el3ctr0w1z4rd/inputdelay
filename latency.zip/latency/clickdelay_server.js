const express = require("express");
const app = express();
const path = require("path");

app.use(express.static("frontend"));
app.use(express.json());

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "frontend", "clickdelay.html"));
});

app.post("/ping", (req, res) => {
  const serverTime = Date.now();
  res.json({ serverTime });
});

const PORT = process.env.PORT || 3001;
const server = app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${server.address().port}`);
});
