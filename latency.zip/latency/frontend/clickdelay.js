async function checkLatency() {
    const clientStart = Date.now();
    const response = await fetch("/ping", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ clientStart })
    });

    const data = await response.json();
    const clientEnd = Date.now();

    const roundTripTime = clientEnd - clientStart;
    
    document.getElementById("result").innerText =
      `Input Delay: ${roundTripTime} ms`;
  }
